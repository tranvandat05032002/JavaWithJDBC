/**
 * 
 */
/**
 * @author spiderman
 *
 */
module T21t1020285_TranVanDat {
	requires java.sql;
}