package com.tranvandat.baithi;

import java.util.ArrayList;

import com.tranvandat.baithi.DAO.NganhDAO;
import com.tranvandat.baithi.DAO.SinhVienDAO;

public class ChuongTrinh {
	static void getSVCNTTT() {
		SinhVienDAO svDAO = new SinhVienDAO();
		ArrayList<SinhVien> listSVDAO = svDAO.getSinhVienToDatabase();
		System.out.println("STT" + "\t" + "MaSinhVien" + "\t" + "Ho va Ten" + "\t\t" + "GioiTinh" + "\t" + "NgaySinh");
		for (int i = 0; i < listSVDAO.size(); i++) {
			SinhVien x = listSVDAO.get(i);
			if (x.getMaNganh() == 101) {
				System.out.println((i + 1) + "\t" + x.getThongTinCNTT());
			}
		}
	}

	static void getNganhDaoTao() {
		NganhDAO nganhDAO = new NganhDAO();
		ArrayList<NganhDaoTao> listNganh = nganhDAO.getNganhToDatabase();
		System.out.println("STT" + "\t" + "MaNganh" + "\t" + "TenNganhDaoTao");
		for (int i = 0; i < listNganh.size(); i++) {
			NganhDaoTao x = listNganh.get(i);
			System.out.println((i + 1) + "\t" + x.getThongTin());
		}
	}
	static void soSinhVienTheoNganh() {
		SinhVienDAO svDAO = new SinhVienDAO();
		ArrayList<SinhVien> listSVDAO = svDAO.getSinhVienToDatabase();
		NganhDAO nganhDAO = new NganhDAO();
		ArrayList<NganhDaoTao> listNganh = nganhDAO.getNganhToDatabase();
		System.out.println("STT" + "\t" + "Ma DT" + "\t" + "TenNganhDT" + "\t" + "So Sinh Vien");
		for(int i = 0; i < listNganh.size(); i++) {
			NganhDaoTao nganhHoc = listNganh.get(i);
			int countSV = 0;
			for(int j = 0; j < listSVDAO.size(); j++) {
				SinhVien svJ = listSVDAO.get(j);
				if(nganhHoc.getMaNganh() == svJ.getMaNganh()) {
					countSV++;
				}
			}
			System.out.println((i + 1) + "\t" + nganhHoc.getThongTin() + "\t\t" + countSV);
		}
	}
	static void getSinhVienDTBMax() {
		SinhVienDAO svDAO = new SinhVienDAO();
		ArrayList<SinhVien> listSV = svDAO.getSinhVienToDatabase();
		NganhDAO nganhDAO = new NganhDAO();
		ArrayList<NganhDaoTao> listNganh = nganhDAO.getNganhToDatabase();
		double maxDTB = 0;
		for(int i = 0; i < listSV.size(); i++) {
			SinhVien newSinhVien = listSV.get(i);
			if(newSinhVien.getDTB() > maxDTB) {
				maxDTB = newSinhVien.getDTB();
			}
		}
		System.out.println("Danh sach sinh vien co diem trung binh cao nhat:");
		System.out.println("Hoten\t\t\tMaSinhVien\tTenNganh\tDiemTrungBinh");
		for(int i = 0; i < listSV.size(); i++) {
			SinhVien newSinhVien = listSV.get(i);
			if(newSinhVien.getDTB() == maxDTB) {
				for(int j = 0; j < listNganh.size(); j++) {
					NganhDaoTao newNganh  = listNganh.get(j);
					if(newNganh.getMaNganh() == newSinhVien.getMaNganh()) {
						System.out.println(newSinhVien.getHoDem() + " " + newSinhVien.getTen() + "\t\t" + newSinhVien.getMaSinhVien() + "\t\t" + newNganh.getTenNganh() + "\t\t" + newSinhVien.getDTB());
					}
				}
			}
		}
		
	}
	public static void main(String[] args) {
		getSVCNTTT();
		getNganhDaoTao();
		soSinhVienTheoNganh();
		getSinhVienDTBMax();
	}

}
