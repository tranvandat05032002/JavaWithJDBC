package com.tranvandat.baithi.DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.tranvandat.baithi.NganhDaoTao;

public class NganhDAO {
	public ArrayList<NganhDaoTao> getNganhToDatabase() {
		ArrayList<NganhDaoTao> listNganhDaoTao = new ArrayList<>();
		ResultSet rs = null;
		try(Connection cnn = utilsDAO.getDatabaseSQLife()) {
			Statement stmt = cnn.createStatement();
			
			String query = "SELECT MaNganh, TenNganh FROM NganhDaoTao";
			
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				int maNganh = rs.getInt("MaNganh");
				String tenNganh = rs.getString("TenNganh");
				NganhDaoTao newNganh = new NganhDaoTao(maNganh, tenNganh);
				listNganhDaoTao.add(newNganh);
			}
			stmt.close();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return listNganhDaoTao;
	}
}
