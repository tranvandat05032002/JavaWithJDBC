package com.tranvandat.baithi.DAO;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.tranvandat.baithi.SinhVien;

public class SinhVienDAO {
	public ArrayList<SinhVien> getSinhVienToDatabase() {
		ArrayList<SinhVien> listSinhVien = new ArrayList<>();
		ResultSet rs = null;
		try(Connection cnn = utilsDAO.getDatabaseSQLife()) {
			Statement stmt = cnn.createStatement();
			
			String query = "SELECT MaSinhVien, HoDem, Ten, MaNganh, GioiTinh, NgaySinh, DiemTrungBinh FROM SinhVien";
			
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				String maSinhVien = rs.getString("MaSinhVien");
				String hoDem = rs.getString("HoDem");
				String ten = rs.getString("Ten");
				boolean gioiTinh = rs.getBoolean("GioiTinh");
				String ngaySinh = rs.getString("NgaySinh");
				int maNganh = rs.getInt("MaNganh");
				double diemTrungBinh = rs.getDouble("DiemTrungBinh");
				SinhVien newSV = new SinhVien(maSinhVien, hoDem, ten, gioiTinh, ngaySinh, maNganh, diemTrungBinh);
				listSinhVien.add(newSV);
			}
			stmt.close();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return listSinhVien;
	}
}
