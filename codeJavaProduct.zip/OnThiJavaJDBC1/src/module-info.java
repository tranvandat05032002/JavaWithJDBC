/**
 * 
 */
/**
 * @author spiderman
 *
 */
module OnThiJavaJDBC1 {
	requires java.sql;
}