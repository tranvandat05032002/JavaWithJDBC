/**
 * 
 */
/**
 * @author spiderman
 *
 */
module BaiThiK36_TranVanDat {
	requires java.sql;
}