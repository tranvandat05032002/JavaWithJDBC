package com.tvdat.models;

public class Xe0Banh extends infoXeVao {
//	private int loaiXe;
//	private String soVe;
//	private String thoiGianVao;
	public Xe0Banh(int loaiXe, String bienSo, String soVe, String thoiGianVao, String trangThaiVao) {
		super(loaiXe, bienSo, soVe, thoiGianVao, trangThaiVao);
	}
//
	public void formatLoaiXe() {
		setBienSo("");
		setTrangThaiXeVao("");
	}
//	public Xe0Banh(int loaiXe, String soVe, String thoiGianVao) {
//		this.loaiXe = loaiXe;
//		this.soVe = soVe;
//		this.thoiGianVao = thoiGianVao;
//	}
//	public int getLoaiXe() {
//		return loaiXe;
//	}
//	public void setLoaiXe(int loaiXe) {
//		this.loaiXe = loaiXe;
//	}
//	public String getSoVe() {
//		return soVe;
//	}
//	public void setSoVe(String soVe) {
//		this.soVe = soVe;
//	}
//	public String getThoiGianVao() {
//		return thoiGianVao;
//	}
//	public void setThoiGianVao(String thoiGianVao) {
//		this.thoiGianVao = thoiGianVao;
//	}
	
}