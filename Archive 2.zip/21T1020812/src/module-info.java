/**
 * 
 */
/**
 * @author spiderman
 *
 */
module DeChieuJava {
	requires java.sql;
}