package htai.com.thihk.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class NhanVienDAO {
	public boolean insertNhanVien(String maNhanVien, String hoTen, String loaiHopDong, int heSoLuong) throws SQLException {
		Connection cnn = UtilsDAO.getDatabaseSQLife();
		
		String query = "INSERT INTO NhanVien (maNhanVien, hoTen, loaiHopDong, heSoLuong) VALUES(?, ?, ?, ?)";
		
		PreparedStatement stmt = cnn.prepareStatement(query);
		int index = 1;
		stmt.setString(index++, maNhanVien);
		stmt.setString(index++, hoTen);
		stmt.setString(index++, loaiHopDong);
		stmt.setInt(index++, heSoLuong);
		
		//handle results
		int n = stmt.executeUpdate();
		
		stmt.close();
		cnn.close();
		
		return n == 1;
	}
}
