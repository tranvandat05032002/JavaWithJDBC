/**
 * 
 */
/**
 * @author spiderman
 *
 */
module tranhieutai {
	requires java.sql;
}